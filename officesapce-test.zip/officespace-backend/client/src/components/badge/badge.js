                  
import React, {Component} from 'react';
import './badge.css';
import {Row, Col, Container, Navbar} from 'reactstrap';

 class Badge extends Component {
    render(){
        return (

<div>






                      <img src="http://byrobin.nl/store/wp-content/uploads/sites/4/2016/03/local.png" id="notif" />

</div>
)
}
}

export default Badge;
